#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tinyexpr.h"

#define STRLEN 100

//To Do

int main(void) {
	double x;
	int err;
	double l;
	double u;
	int steps;
	char line[STRLEN];
    char fstr[STRLEN];

	// To Do
}
